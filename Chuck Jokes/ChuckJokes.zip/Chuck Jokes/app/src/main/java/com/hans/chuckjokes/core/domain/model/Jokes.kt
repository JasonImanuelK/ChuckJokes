package com.hans.chuckjokes.core.domain.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Jokes(
    val icon_url: String,
    val id: String,
    val url: String,
    val value: String,
    val isFavorite: Boolean
) : Parcelable